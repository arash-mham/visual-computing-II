Please download KingsCollege dataset from https://www.repository.cam.ac.uk/handle/1810/251342/

e.g. wget https://www.repository.cam.ac.uk/bitstream/handle/1810/251342/KingsCollege.zip