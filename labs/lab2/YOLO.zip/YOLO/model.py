import os
import random
import numpy as np

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torch.optim as optim
import torch.utils.data
import torchvision.datasets as dset
import torchvision.transforms as transforms
import torchvision.utils as vutils
from torch.autograd import Variable
import torch.nn.functional as F




def YOLO_loss(pred_confidence, pred_box, ann_confidence, ann_box):
    #input:
    #pred_confidence -- the predicted class labels from YOLO, [batch_size, 5,5, num_of_classes]
    #pred_box        -- the predicted bounding boxes from YOLO, [batch_size, 5,5, 4]
    #ann_confidence  -- the ground truth class labels, [batch_size, 5,5, num_of_classes]
    #ann_box         -- the ground truth bounding boxes, [batch_size, 5,5, 4]
    #
    #output:
    #loss -- a single number for the value of the loss function, [1]
    
    #TODO: write a loss function for YOLO
    #
    #For confidence (class labels), use cross entropy (F.cross_entropy)
    #You can try F.binary_cross_entropy and see which loss is better
    #For box (bounding boxes), use smooth L1 (F.smooth_l1_loss).
    #
    #Note that you need to consider cells carrying objects and empty cells separately.
    #I suggest you to reshape confidence to [batch_size*5*5, num_of_classes]
    #and reshape box to [batch_size*5*5, 4].
    #Then you need to figure out how you can get the indices of all cells carrying objects,
    #and use confidence[indices], box[indices] to select those cells.



'''
YOLO network
Please refer to the hand-out for better visualization

N is batch_size
bn is batch normalization layer
relu is ReLU activation layer
conv(cin,cout,ksize,stride) is convolution layer
  cin - the number of input channels
  cout - the number of output channels
  ksize - kernel size
  stride - stride
  padding - you need to figure this out by yourself

input -> [N,3,320,320]

conv(  3, 64, 3, 2),bn,relu -> [N,64,160,160]

conv( 64, 64, 3, 1),bn,relu -> [N,64,160,160]
conv( 64, 64, 3, 1),bn,relu -> [N,64,160,160]
conv( 64,128, 3, 2),bn,relu -> [N,128,80,80]

conv(128,128, 3, 1),bn,relu -> [N,128,80,80]
conv(128,128, 3, 1),bn,relu -> [N,128,80,80]
conv(128,256, 3, 2),bn,relu -> [N,256,40,40]

conv(256,256, 3, 1),bn,relu -> [N,256,40,40]
conv(256,256, 3, 1),bn,relu -> [N,256,40,40]
conv(256,512, 3, 2),bn,relu -> [N,512,20,20]

conv(512,512, 3, 1),bn,relu -> [N,512,20,20]
conv(512,512, 3, 1),bn,relu -> [N,512,20,20]
conv(512,256, 3, 2),bn,relu -> [N,256,10,10]

conv(256,256, 1, 1),bn,relu -> [N,256,10,10]
conv(256,256, 3, 2),bn,relu -> [N,256,5,5] (the last hidden layer)

output layer 1 - confidence
(from the last hidden layer)
conv(256,num_of_classes, 3, 1),softmax? -> [N,num_of_classes,5,5]
permute (or transpose) -> [N,5,5,num_of_classes]

output layer 2 - bounding boxes
(from the last hidden layer)
conv(256, 4, 3, 1) -> [N,4,5,5]
permute (or transpose) -> [N,5,5,4]
'''


class YOLO(nn.Module):

    def __init__(self, class_num):
        super(YOLO, self).__init__()
        
        self.class_num = class_num #num_of_classes, in this assignment, 4: cat, dog, person, background
        
        #TODO: define layers
        
    def forward(self, x):
        #input:
        #x -- images, [batch_size, 3, 320, 320]
        
        x = x/255.0 #normalize image. If you already normalized your input image in the dataloader, remove this line.
    
        #TODO: define forward
        
        #should you apply softmax to confidence? (search the pytorch tutorial for F.cross_entropy.) If yes, which dimension should you apply softmax?
        
        #sanity check: print the size/shape of the confidence and bboxes, make sure they are as follows:
        #confidence - [batch_size,5,5,num_of_classes]
        #bboxes - [batch_size,5,5,4]
        
        return confidence,bboxes










